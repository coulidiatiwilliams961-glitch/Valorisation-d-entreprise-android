-- SCHEMA DE DEMONSTRATION SEULEMENT. Ne pas utiliser avec des données confidentielles.
create table if not exists public.company_portfolios (
 owner_id text not null, company_id text not null, payload jsonb not null,
 updated_at timestamptz not null default now(), primary key(owner_id,company_id));
alter table public.company_portfolios enable row level security;
-- Ces politiques ouvertes sont uniquement pour un test non sensible.
-- Pour la production, supprimer les trois politiques et utiliser Supabase Auth + auth.uid().
create policy "demo read portfolios" on public.company_portfolios for select to anon using (true);
create policy "demo insert portfolios" on public.company_portfolios for insert to anon with check (true);
create policy "demo update portfolios" on public.company_portfolios for update to anon using (true) with check (true);
