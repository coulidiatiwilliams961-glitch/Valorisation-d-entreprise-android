VALORISATION D'ENTREPRISE — PROJET ANDROID V1.1

Ce ZIP est le projet source, PAS un APK déjà compilé.

Fonctionnalités : intégration des feuilles Excel en lecture seule; création/modification de dossiers multi-entreprises stockés localement; export CSV compatible Excel; rapport imprimable en PDF; sauvegarde/restauration JSON; synchronisation Supabase préparée mais à configurer; compilation APK par GitHub Actions.

OBTENIR L'APK DEPUIS LE TÉLÉPHONE
1. Télécharge le ZIP et ouvre-le dans Mes fichiers > Téléchargements > Extraire.
2. Dans le navigateur Android, ouvre github.com et connecte-toi/crée un compte.
3. Crée un dépôt vide, par exemple valorisation-entreprise-android.
4. Téléverse tous les fichiers du projet en conservant les dossiers. Si nécessaire, active « Site pour ordinateur ». Vérifie que build.gradle, settings.gradle, app/ et .github/workflows/build-apk.yml sont à la racine.
5. Ouvre Actions > Build Android APK > Run workflow.
6. Quand l'exécution est verte, ouvre-la, télécharge l'artefact ValorisationEntreprise-debug-apk.
7. Décompresse l'artefact : app-debug.apk. Appuie dessus et autorise si Android demande l'installation depuis cette source.
Si l'import sur GitHub depuis le mobile est trop difficile, demande à une personne de confiance de faire uniquement l'import et le lancement de la compilation; ne partage pas ton mot de passe.

CLOUD
1. Crée un projet Supabase.
2. Dans SQL Editor, exécute supabase_schema.sql.
3. Récupère l'URL du projet et sa clé publique (anon/publishable) dans les paramètres API.
4. Dans l'application > Synchronisation, renseigne URL, clé publique et identifiant de compte, puis Synchroniser maintenant.
IMPORTANT : le SQL livré utilise des politiques d'accès de démonstration ouvertes. Ne mets aucune donnée client confidentielle avant d'avoir configuré Supabase Auth et des politiques RLS strictes par utilisateur. L'identifiant partagé n'est pas une authentification sécurisée.

PDF / EXCEL
Dans un dossier, enregistre les chiffres puis clique Rapport PDF. Utilise la fonction d'impression / Enregistrer en PDF si proposée. Les exportations CSV s'ouvrent dans Excel, mais ce ne sont pas des classeurs XLSX natifs.

LIMITES
Le classeur est intégré avec les valeurs enregistrées. Les formules Excel ne sont pas recalculées et les méthodes ANCC, DCF, Goodwill ne sont pas encore automatisées à partir des feuilles sources. Contrôle toutes les hypothèses avant usage professionnel. L'APK généré est une version debug d'essai; une diffusion professionnelle nécessite signature release et tests sur appareil.
