package com.valorisation.entreprise;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import android.graphics.Color; import android.content.Intent; import android.net.Uri;
public class MainActivity extends Activity {
 private WebView webView;
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(16,42,67));getWindow().setNavigationBarColor(Color.rgb(16,42,67));webView=new WebView(this);webView.setBackgroundColor(Color.rgb(242,245,249));WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setSupportZoom(true);s.setBuiltInZoomControls(false);webView.setWebViewClient(new WebViewClient());webView.setWebChromeClient(new WebChromeClient());setContentView(webView);webView.loadUrl("file:///android_asset/index.html");}
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}